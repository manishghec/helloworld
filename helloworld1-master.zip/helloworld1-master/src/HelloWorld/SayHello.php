<?php 

namespace HelloWorld;

class SayHello
{
    public static function world()
    {
        return 'Hello World, wow !! This is generated using Composer. :)';
    }
}